public class Main {
    public static void main(String[] args) {
        String language = "ENG";
        if (args.length > 0) {
            language = args[0];
        }
        String greeting = getLocalizedGreeting(language);
        System.out.println(greeting);
    }

    private static String getLocalizedGreeting(String language) {
        // 3-letter ISO 639-3 language codes.
        String[] languages = new String[] {
            "ENG", "ESP", "DEU", "FRA"
        };
        String[] greetings = new String[] {
            "Hello world!",
            "¡Hola mundo!",
            "Hallo Welt!",
            "Bonjour le monde!"
        };
        for (int i = 0; i < languages.length; i++) {
            if (languages[i].equals(language)) {
                return greetings[i];
            }
        }
        return greetings[0];  // default language
    }
}

