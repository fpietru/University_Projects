public class Main {
    public static void main(String[] args) {
        String greeting = "Hello world!";  // a friendly greeting
        if (args.length > 0 && args[0].equals("ESP")) {
            greeting = "¡Hola mundo!";
        }
        System.out.println(greeting);
    }
}

