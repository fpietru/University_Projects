public class Main {
    public static void main(String[] args) {
        normalizeArguments(args);

        System.out.println("Hello world!"); // a friendly greeting
    }

    private static void normalizeArguments(String[] args) {
        for (int i = 0; i < args.length; i++) {
            args[i] = args[i].toLowerCase();
        }
    }
}

